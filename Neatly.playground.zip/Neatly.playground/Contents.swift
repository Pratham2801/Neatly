import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    @State private var selectedTab: Int = 0
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 40)
                .fill(Color.black)
                .frame(width: 375, height: 812)
                .shadow(radius: 20)
            
            VStack(spacing: 0) {
    
                HStack {
                    Text("11:11")
                        .font(.system(size: 14, weight: .semibold))
                    Spacer()
                    HStack(spacing: 6) {
                        Image(systemName: "cellularbars")
                        Image(systemName: "wifi")
                        Image(systemName: "battery.75")
                    }
                }
                .foregroundColor(.black)
                .padding(.horizontal, 24)
                .padding(.top, 50)
                .padding(.bottom, 8)
                
                // Tab Content
                TabView(selection: $selectedTab) {
                    HomeScreen(selectedTab: $selectedTab)
                        .tag(0)
                    TasksScreen()
                        .tag(1)
                    HabitsScreen()
                        .tag(2)
                    NotesScreen()
                        .tag(3)
                }
                .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                
              
                HStack {
                    TabBarButton(icon: "house.fill", label: "Home", isSelected: selectedTab == 0) {
                        selectedTab = 0
                    }
                    TabBarButton(icon: "checklist", label: "Tasks", isSelected: selectedTab == 1) {
                        selectedTab = 1
                    }
                    TabBarButton(icon: "heart.fill", label: "Habits", isSelected: selectedTab == 2) {
                        selectedTab = 2
                    }
                    TabBarButton(icon: "note.text", label: "Notes", isSelected: selectedTab == 3) {
                        selectedTab = 3
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 8)
                .background(Color.white)
                .cornerRadius(20)
                .shadow(color: .black.opacity(0.1), radius: 10, x: 0, y: -5)
                .padding(.horizontal, 16)
                .padding(.bottom, 8)
            }
            .background(Color(.systemGray6))
            .frame(width: 375, height: 812)
            .clipShape(RoundedRectangle(cornerRadius: 40))
        }
    }
}


struct HomeScreen: View {
    @Binding var selectedTab: Int
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                Text("Neatly")
                    .font(.system(size: 32, weight: .bold, design: .rounded))
                    .foregroundStyle(LinearGradient(
                        colors: [Color.purple, Color.blue],
                        startPoint: .leading,
                        endPoint: .trailing
                    ))
                    .padding(.top, 20)
                
          
                HStack(spacing: 20) {
                    QuickActionButton(icon: "plus", label: "Add Task", color: .purple) {
                        selectedTab = 1 // Navigate to Tasks Screen
                    }
                    QuickActionButton(icon: "heart.fill", label: "Add Habit", color: .orange) {
                        selectedTab = 2 // Navigate to Habits Screen
                    }
                    QuickActionButton(icon: "note.text", label: "Add Note", color: .blue) {
                        selectedTab = 3 // Navigate to Notes Screen
                    }
                }
                .padding(.horizontal, 20)
                
                // Recent Activity
                VStack(alignment: .leading, spacing: 10) {
                    Text("Recent Activity")
                        .font(.system(size: 20, weight: .semibold, design: .rounded))
                    
                    Text("No recent activity yet.")
                        .font(.system(size: 16, design: .rounded))
                        .foregroundColor(.gray)
                }
                .padding()
                .background(Color.white)
                .cornerRadius(20)
                .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
                .padding(.horizontal, 20)
            }
        }
    }
}

struct TasksScreen: View {
    @State private var tasks = [
        Task(name: "Buy groceries", category: "Personal", priority: "Medium", deadline: Date()),
        Task(name: "Finish report", category: "Work", priority: "High", deadline: Date().addingTimeInterval(86400))
    ]
    @State private var newTask = ""
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                ForEach(tasks.indices, id: \.self) { index in
                    TaskCard(task: $tasks[index])
                }
                
                HStack {
                    TextField("Add a new task...", text: $newTask)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    Button(action: addTask) {
                        Image(systemName: "plus.circle.fill")
                            .font(.title2)
                            .foregroundColor(.purple)
                    }
                }
                .padding(.horizontal, 20)
            }
            .padding(.vertical, 20)
        }
    }
    
    func addTask() {
        guard !newTask.isEmpty else { return }
        tasks.append(Task(name: newTask, category: "Personal", priority: "Low", deadline: Date()))
        newTask = ""
    }
}

// MARK: - Habits Screen
struct HabitsScreen: View {
    @State private var habits = [
        Habit(name: "💧 Drink Water", completed: false, streak: 5),
        Habit(name: "🏋️ Exercise", completed: true, streak: 10)
    ]
    @State private var newHabit = ""
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                ForEach(habits.indices, id: \.self) { index in
                    HabitCard(habit: $habits[index])
                }
                
                HStack {
                    TextField("Add a new habit...", text: $newHabit)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    Button(action: addHabit) {
                        Image(systemName: "plus.circle.fill")
                            .font(.title2)
                            .foregroundColor(.orange)
                    }
                }
                .padding(.horizontal, 20)
            }
            .padding(.vertical, 20)
        }
    }
    
    func addHabit() {
        guard !newHabit.isEmpty else { return }
        habits.append(Habit(name: newHabit, completed: false, streak: 0))
        newHabit = ""
    }
}

// MARK: - Notes Screen
struct NotesScreen: View {
    @State private var notes = [
        Note(text: "Welcome to QuickSort! #GettingStarted", tags: ["#GettingStarted"], color: .blue),
        Note(text: "Plan weekend trip #Travel #Fun", tags: ["#Travel", "#Fun"], color: .green)
    ]
    @State private var newNote = ""
    @State private var searchText = ""
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                TextField("Search notes...", text: $searchText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal, 20)
                
                ForEach(notes.indices, id: \.self) { index in
                    NoteCard(note: $notes[index])
                }
                
                HStack {
                    TextField("Add a new note...", text: $newNote)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    Button(action: addNote) {
                        Image(systemName: "plus.circle.fill")
                            .font(.title2)
                            .foregroundColor(.blue)
                    }
                }
                .padding(.horizontal, 20)
            }
            .padding(.vertical, 20)
        }
    }
    
    func addNote() {
        guard !newNote.isEmpty else { return }
        let tags = newNote.components(separatedBy: " ").filter { $0.hasPrefix("#") }
        let color = [Color.blue, .green, .orange, .purple].randomElement() ?? .blue
        notes.append(Note(text: newNote, tags: tags, color: color))
        newNote = ""
    }
}

struct TaskCard: View {
    @Binding var task: Task
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(task.name)
                .font(.system(size: 18, weight: .semibold, design: .rounded))
            HStack {
                Text(task.category)
                    .font(.caption)
                    .padding(4)
                    .background(Color.purple.opacity(0.2))
                    .cornerRadius(4)
                Text(task.priority)
                    .font(.caption)
                    .padding(4)
                    .background(Color.orange.opacity(0.2))
                    .cornerRadius(4)
                Spacer()
                Text(task.deadline, style: .date)
                    .font(.caption)
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(20)
        .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
        .padding(.horizontal, 20)
    }
}

struct HabitCard: View {
    @Binding var habit: Habit
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(habit.name)
                .font(.system(size: 18, weight: .semibold, design: .rounded))
            HStack {
                Text("Streak: \(habit.streak)")
                    .font(.caption)
                    .padding(4)
                    .background(Color.orange.opacity(0.2))
                    .cornerRadius(4)
                Spacer()
                Button(action: { habit.completed.toggle() }) {
                    Image(systemName: habit.completed ? "checkmark.circle.fill" : "circle")
                        .foregroundColor(habit.completed ? .green : .gray)
                }
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(20)
        .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
        .padding(.horizontal, 20)
    }
}

struct NoteCard: View {
    @Binding var note: Note
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(note.text)
                .font(.system(size: 16, design: .rounded))
            HStack {
                ForEach(note.tags, id: \.self) { tag in
                    Text(tag)
                        .font(.caption)
                        .padding(4)
                        .background(note.color.opacity(0.2))
                        .cornerRadius(4)
                }
                Spacer()
                Button(action: {}) {
                    Image(systemName: "trash")
                        .foregroundColor(.red)
                }
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(20)
        .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
        .padding(.horizontal, 20)
    }
}

struct QuickActionButton: View {
    let icon: String
    let label: String
    let color: Color
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack {
                Image(systemName: icon)
                    .font(.system(size: 24))
                    .foregroundColor(.white)
                    .padding(16)
                    .background(Circle().fill(color))
                Text(label)
                    .font(.system(size: 14, weight: .medium, design: .rounded))
            }
        }
    }
}

struct TabBarButton: View {
    let icon: String
    let label: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack {
                Image(systemName: icon)
                    .font(.system(size: 24))
                    .foregroundColor(isSelected ? .purple : .gray)
                Text(label)
                    .font(.system(size: 12, weight: .medium, design: .rounded))
                    .foregroundColor(isSelected ? .purple : .gray)
            }
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: - Models
struct Task: Identifiable {
    let id = UUID()
    var name: String
    var category: String
    var priority: String
    var deadline: Date
}

struct Habit: Identifiable {
    let id = UUID()
    var name: String
    var completed: Bool
    var streak: Int
}

struct Note: Identifiable {
    let id = UUID()
    var text: String
    var tags: [String]
    var color: Color
}

PlaygroundPage.current.setLiveView(ContentView())
